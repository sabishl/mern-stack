import React, { useState } from 'react';
import './payment.css';

const Payment = () => {
  const [paymentMethod, setPaymentMethod] = useState('');

  const handlePaymentMethodChange = (e) => {
    setPaymentMethod(e.target.value);
  };

  const handlePaymentSubmit = (e) => {
    e.preventDefault();
    // Here you can implement the logic to process payment based on selected method
    if (paymentMethod === 'card') {
      console.log('Processing card payment...');
      // Implement card payment processing logic
    } else if (paymentMethod === 'upi') {
      console.log('Processing UPI payment...');
      // Implement UPI payment processing logic
    }
    // Reset payment method after submission
    setPaymentMethod('');
  };

  return (
    <div className="payment-container">
      <h2>Payment Options</h2>
      <form onSubmit={handlePaymentSubmit}>
        <div className="radio-group">
          <input
            type="radio"
            id="card"
            name="paymentMethod"
            value="card"
            checked={paymentMethod === 'card'}
            onChange={handlePaymentMethodChange}
          />
          <label htmlFor="card">Credit/Debit Card</label>
        </div>
        <div className="radio-group">
          <input
            type="radio"
            id="upi"
            name="paymentMethod"
            value="upi"
            checked={paymentMethod === 'upi'}
            onChange={handlePaymentMethodChange}
          />
          <label htmlFor="upi">UPI (Unified Payments Interface)</label>
        </div>
        <button type="submit">Proceed to Pay</button>
      </form>
    </div>
  );
};

export default Payment;
