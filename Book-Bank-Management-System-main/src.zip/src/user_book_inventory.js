import React, { useState } from 'react';
import './user_book_inventory.css';

const UserBookInventory = () => {
  const books = [
    { id: 1, title: 'Book One', author: 'Author One', year: 2020, imageUrl: 'https://m.media-amazon.com/images/I/71uN0nVAkvL._AC_UF1000,1000_QL80_.jpg' },
    { id: 2, title: 'Book Two', author: 'Author Two', year: 2018, imageUrl: 'https://m.media-amazon.com/images/I/51EWRgaqIKL.jpg' },
    { id: 3, title: 'Book Three', author: 'Author Three', year: 2015, imageUrl: 'https://m.media-amazon.com/images/I/411t3aQzVaL.jpg' },
    // Add more books as needed
  ];

  const [selectedBook, setSelectedBook] = useState(null);

  const handleDownloadBook = (book) => {
    console.log(`Download Book ${book.id} clicked`);

    // Create a temporary anchor element
    const link = document.createElement('a');
    link.href = book.imageUrl; // Use the book's image URL for download
    link.download = `${book.title}.jpg`; // Set the download filename

    // Append the link to the body
    document.body.appendChild(link);

    // Trigger the download
    link.click();

    // Clean up: remove the link from the DOM
    document.body.removeChild(link);
  };

  const handleViewBook = (book) => {
    console.log(`View Book ${book.id} clicked`);
    setSelectedBook(book);
  };

  const handleCloseModal = () => {
    setSelectedBook(null);
  };

  return (
    <div className="book-inventory-container">
      <h2>Book Inventory</h2>
      <table className="book-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Author</th>
            <th>Year</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {books.map((book) => (
            <tr key={book.id}>
              <td>{book.id}</td>
              <td>{book.title}</td>
              <td>{book.author}</td>
              <td>{book.year}</td>
              <td>
                <button className="action-button" onClick={() => handleDownloadBook(book)}>
                  Download
                </button>
                <button className="action-button" onClick={() => handleViewBook(book)}>
                  View
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {selectedBook && (
        <div className="modal">
          <div className="modal-content">
            <span className="close" onClick={handleCloseModal}>&times;</span>
            <h3>{selectedBook.title}</h3>
            <p>Author: {selectedBook.author}</p>
            <p>Year: {selectedBook.year}</p>
            <img src={selectedBook.imageUrl} alt={selectedBook.title} />
          </div>
        </div>
      )}
    </div>
  );
};

export default UserBookInventory;
