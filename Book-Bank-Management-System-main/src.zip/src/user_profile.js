import React, { useState, useEffect } from 'react';

const UserProfile = ({ user }) => {
  const [userData, setUserData] = useState(user);

  // useEffect to update the userData if the 'user' prop changes
  useEffect(() => {
    setUserData(user);
  }, [user]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUserData({ ...userData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Here you can implement logic to update the user's profile data
    console.log('Updated user data:', userData);
    // Example: call an API to update the user's profile data
    // updateUserProfile(userData);
    // You would implement the 'updateUserProfile' function to handle the API call
  };

  return (
    <div>
      <h2>User Profile</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="username">Username:</label>
          <input
            type="text"
            id="username"
            name="username"
            value={userData.username}
            onChange={handleInputChange}
          />
        </div>
        <div>
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            id="email"
            name="email"
            value={userData.email}
            onChange={handleInputChange}
          />
        </div>
        <div>
          <label htmlFor="phone">Phone:</label>
          <input
            type="text"
            id="phone"
            name="phone"
            value={userData.phone}
            onChange={handleInputChange}
          />
        </div>
        <button type="submit">Update Profile</button>
      </form>
    </div>
  );
};

export default UserProfile;
