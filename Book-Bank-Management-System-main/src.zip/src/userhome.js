import React from 'react';
import './userhome.css';
import { Link } from 'react-router-dom';

const UserHome = () => {
  return (
    <div className="home-container">
      <h1>Welcome to the Book Bank Management System</h1>
      <p>
        This system allows users to borrow and return books from the book bank.
        Manage your books efficiently with our user-friendly interface.
      </p>
      <div className="action-buttons">
        <Link to="/user_book_inventory" className="action-button">
          Book Inventory
        </Link>
        <Link to="/profile" className="action-button">
          User Profile
        </Link>
      </div>
    </div>
  );
};

export default UserHome;
