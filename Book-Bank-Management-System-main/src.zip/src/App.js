import React from 'react';
import Intro from './intro';
import Home from './home';

import { BrowserRouter, Routes, Route } from "react-router-dom";
import './App.css'; // Import main styles
import Login from './login';
import BookInventory from './book_inventory';
import SignUp from './signup';
import UserHome from './userhome';
import UserLogin from './userlogin';
import UserBookInventory from './user_book_inventory';
import UserProfile from './user_profile';

const App = () => {
  return (
    <BrowserRouter>
      <Routes>
      <Route path="/" element={<Intro/>} />
      <Route path="/Home" element={<Home />} />
      <Route path="/Login" element={<Login/>} />
      <Route path="/book_inventory" element={<BookInventory/>} />
      <Route path="/signup" element={<SignUp/>} />
      <Route path="/userhome" element={<UserHome/>} />
      <Route path="/userlogin" element={<UserLogin/>} />
      <Route path="/user_book_inventory" element={<UserBookInventory/>} />
      <Route path="/user_profile" element={<UserProfile/>} />


      </Routes>
      </BrowserRouter>
  );
};

export default App;