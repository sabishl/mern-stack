import React, { useState } from 'react';
import './book_inventory.css';

const BookInventory = () => {
  const initialBooks = [
    { id: 1, title: 'Book One', author: 'Author One', year: 2020, imageUrl: 'https://m.media-amazon.com/images/I/71uN0nVAkvL._AC_UF1000,1000_QL80_.jpg' },
    { id: 2, title: 'Book Two', author: 'Author Two', year: 2018, imageUrl: 'https://m.media-amazon.com/images/I/51EWRgaqIKL.jpg' },
    { id: 3, title: 'Book Three', author: 'Author Three', year: 2015, imageUrl: 'https://m.media-amazon.com/images/I/411t3aQzVaL.jpg' },
  ];

  const [books, setBooks] = useState(initialBooks);
  const [isAdding, setIsAdding] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editedBookData, setEditedBookData] = useState({
    id: null,
    title: '',
    author: '',
    year: '',
    imageUrl: '',
  });

  const handleAddBook = () => {
    setIsAdding(true);
    setIsEditing(false); // Ensure edit mode is off
    setEditedBookData({
      id: null,
      title: '',
      author: '',
      year: '',
      imageUrl: '',
    });
  };

  const handleEditBook = (id) => {
    const bookToEdit = books.find((book) => book.id === id);
    setIsAdding(true);
    setIsEditing(true);
    setEditedBookData(bookToEdit);
  };

  const handleCancelAdd = () => {
    setIsAdding(false);
    setIsEditing(false);
    setEditedBookData({
      id: null,
      title: '',
      author: '',
      year: '',
      imageUrl: '',
    });
  };

  const handleSubmitAdd = () => {
    if (isEditing) {
      // Update existing book
      const updatedBooks = books.map((book) =>
        book.id === editedBookData.id ? { ...book, ...editedBookData } : book
      );
      setBooks(updatedBooks);
    } else {
      // Add new book
      const newBook = {
        id: books.length + 1,
        ...editedBookData,
      };
      setBooks([...books, newBook]);
    }
    setIsAdding(false);
    setIsEditing(false);
    setEditedBookData({
      id: null,
      title: '',
      author: '',
      year: '',
      imageUrl: '',
    });
  };

  const handleDeleteBook = (id) => {
    const updatedBooks = books.filter((book) => book.id !== id);
    setBooks(updatedBooks);
  };

  const handleViewBook = (book) => {
    alert(`View Book: ${book.title} by ${book.author}`);
    // Implement your view logic here, such as displaying a modal with book details
  };

  return (
    <div className="book-inventory-container">
      <h2>Book Inventory</h2>
      <button className="action-button" onClick={handleAddBook}>
        Add Book
      </button>
      {isAdding && (
        <div className="add-book-form">
          <h3>{isEditing ? 'Edit Book' : 'Add New Book'}</h3>
          <input
            type="text"
            placeholder="Title"
            value={editedBookData.title}
            onChange={(e) => setEditedBookData({ ...editedBookData, title: e.target.value })}
          />
          <input
            type="text"
            placeholder="Author"
            value={editedBookData.author}
            onChange={(e) => setEditedBookData({ ...editedBookData, author: e.target.value })}
          />
          <input
            type="number"
            placeholder="Year"
            value={editedBookData.year}
            onChange={(e) => setEditedBookData({ ...editedBookData, year: e.target.value })}
          />
          <input
            type="text"
            placeholder="Image URL"
            value={editedBookData.imageUrl}
            onChange={(e) => setEditedBookData({ ...editedBookData, imageUrl: e.target.value })}
          />
          <button onClick={handleSubmitAdd}>{isEditing ? 'Update' : 'Submit'}</button>
          <button onClick={handleCancelAdd}>Cancel</button>
        </div>
      )}
      <table className="book-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Author</th>
            <th>Year</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {books.map((book) => (
            <tr key={book.id}>
              <td>{book.id}</td>
              <td>{book.title}</td>
              <td>{book.author}</td>
              <td>{book.year}</td>
              <td>
                <button className="action-button" onClick={() => handleEditBook(book.id)}>
                  Edit
                </button>
                <button className="action-button" onClick={() => handleDeleteBook(book.id)}>
                  Delete
                </button>
                <button className="action-button" onClick={() => handleViewBook(book)}>
                  View
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default BookInventory;
