import React, { useState } from 'react';
import './UserProfile.css';

const UserProfile = ({ user }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editedUser, setEditedUser] = useState({ ...user });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditedUser({ ...editedUser, [name]: value });
  };

  const handleEditClick = () => {
    setIsEditing(true);
  };

  const handleSaveClick = () => {
    // Here you can implement the logic to save the edited user profile (e.g., send API request)
    console.log('Saving user profile:', editedUser);
    setIsEditing(false);
  };

  return (
    <div className="user-profile-container">
      <h2>User Profile</h2>
      <div className="user-details">
        <div className="field">
          <label>Name:</label>
          {isEditing ? (
            <input
              type="text"
              name="name"
              value={editedUser.name}
              onChange={handleInputChange}
            />
          ) : (
            <span>{editedUser.name}</span>
          )}
        </div>
        <div className="field">
          <label>Email:</label>
          <span>{editedUser.email}</span>
        </div>
        <div className="field">
          <label>Address:</label>
          {isEditing ? (
            <input
              type="text"
              name="address"
              value={editedUser.address}
              onChange={handleInputChange}
            />
          ) : (
            <span>{editedUser.address}</span>
          )}
        </div>
        <div className="field">
          <label>Phone Number:</label>
          {isEditing ? (
            <input
              type="text"
              name="phoneNumber"
              value={editedUser.phoneNumber}
              onChange={handleInputChange}
            />
          ) : (
            <span>{editedUser.phoneNumber}</span>
          )}
        </div>
      </div>
      <div className="profile-actions">
        {isEditing ? (
          <button onClick={handleSaveClick}>Save</button>
        ) : (
          <button onClick={handleEditClick}>Edit Profile</button>
        )}
      </div>
    </div>
  );
};

export default UserProfile;
