import React from 'react';
import './home.css';
import { useNavigate } from 'react-router-dom';

const Home = () => {
  const navigate = useNavigate();

  return (
    <div className="home-container">
      <header className="home-header">
        <h1>Welcome to Trading System</h1>
        <p>Manage your trades efficiently with our platform.</p>
        <button className="view-trades" onClick={() => { navigate('/trades') }}>View All Trades</button>
      </header>

      <section className="home-features">
        <div className="feature">
          <h2>Trade Execution</h2>
          <p>Execute buy and sell orders seamlessly.</p>
        </div>
        <div className="feature">
          <h2>Market Analysis</h2>
          <p>Analyze market trends and make informed decisions.</p>
        </div>
        <div className="feature">
          <h2>Real-time Updates</h2>
          <p>Receive real-time updates on trades and market data.</p>
        </div>
      </section>

      <footer className="home-footer">
        <p>Powered by React. Learn more about <a href="https://reactjs.org" target="_blank" rel="noopener noreferrer">React</a>.</p>
      </footer>
    </div>
  );
};

export default Home;
