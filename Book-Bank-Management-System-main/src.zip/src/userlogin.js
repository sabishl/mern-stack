import React, { useState } from 'react';
import './userlogin.css';
import { useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom';

const UserLogin = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (event) => {
    event.preventDefault();

    try {
      const response = await fetch('http://localhost:5000/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, password }) // Send username instead of email
      });

      const data = await response.json();

      if (response.ok) {
        // Authentication successful
        console.log('Login successful:', data);
        navigate('/Home'); // Redirect to Home page after successful login
      } else {
        // Authentication failed
        console.log('Login failed:', data.error);
        // Handle login error (show error message to user)
      }
    } catch (error) {
      console.error('Login error:', error);
      // Handle network error or other exceptions
    }
  };

  return (
    <div className="login-container">
      <h1>Login</h1>
      <form onSubmit={handleSubmit}>
        <label htmlFor="username">Username:</label> {/* Update label to Username */}
        <input
          type="text"
          id="username"
          value={username}
          onChange={(event) => setUsername(event.target.value)}
          required
        />
        <br />
        <label htmlFor="password">Password:</label>
        <input
          type="password"
          id="password"
          value={password}
          onChange={(event) => setPassword(event.target.value)}
          required
        />
        <br />
        <button type="submit">Login</button>
      </form>
      <p>
        Don't have an account? <Link to="/signup">Sign up</Link>
      </p>
    </div>
  );
};

export default UserLogin;
