import React from 'react';
import './intro.css'; // Importing the CSS file for styling
import { useNavigate } from 'react-router-dom';

const Intro = () => {
  const navigate = useNavigate();

  return (
    <div className="intro-container">
      <h1>Welcome to Our Trading System</h1>
      <p>
        Manage your trades efficiently with our advanced trading platform. Stay updated with market trends,
        execute trades seamlessly, and explore powerful tools to optimize your investment strategies.
      </p>
      <p>
        Sign in to access your account or create a new account to start trading today.
      </p>
      <button className="login-button" onClick={() => { navigate('/Login') }}>Login as Trader</button>
      <a href="/AdminLogin" className="admin-login-button">Login as Admin Trader</a>
    </div>
  );
};

export default Intro;
