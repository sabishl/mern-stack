

const mongoose = require('mongoose');
const { Schema } = mongoose;

const userSchema = new Schema({
  MobileNumber: { type: String, required: true },
  UserName: { type: String, required: true },
  City: { type: String, required: true },
  Password: { type: String, required: true }
});

const User = mongoose.model('User', userSchema);

module.exports = User;
