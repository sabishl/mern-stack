const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const User = require('./usermodel');

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://localhost:27017/BBMS', {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log('MongoDB connected'))
.catch((err) => console.error('Error connecting to MongoDB:', err));

app.post('/login', async (req, res) => {
    const { username, password } = req.body;
  
    try {
      const user = await User.findOne({ UserName: username, Password: password });
  
      if (!user) {
        return res.status(401).json({ error: 'Invalid username or password' });
      }
  
      // Authentication successful
      res.status(200).json({ message: 'Login successful', user });
    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  });
  
app.post('/register', async (req, res) => {
  const { mobileNumber, username, city, password } = req.body;

  try {
    // Validate required fields
    if (!mobileNumber || !username || !city || !password) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    const existingUser = await User.findOne({ MobileNumber: mobileNumber });

    if (existingUser) {
      return res.status(400).json({ error: 'Mobile number already exists' });
    }

    const newUser = new User({
      MobileNumber: mobileNumber,
      UserName: username,
      City: city,
      Password: password
    });

    await newUser.save();
    console.log('User registered successfully:', newUser);
    res.status(200).json({ message: 'User registered successfully' });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Server is listening on port ${PORT}`);
});
